import LoginPage from "../pages/LoginPage";

// Tez-tez istifadə olunan "login" hərəkətini custom command edirik.
// Beləliklə hər testdə LoginPage import etmək əvəzinə cy.login() çağıra bilərik.
Cypress.Commands.add("login", (username, password) => {
  LoginPage.visit();
  LoginPage.login(username, password);
});
