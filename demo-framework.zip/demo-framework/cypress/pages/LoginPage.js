class LoginPage {
  // ---- Lokatorlar ----
  elements = {
    usernameInput: () => cy.get('[data-test="username"]'),
    passwordInput: () => cy.get('[data-test="password"]'),
    loginButton: () => cy.get('[data-test="login-button"]'),
    errorMessage: () => cy.get('[data-test="error"]'),
  };

  // ---- Hərəkətlər (actions) ----
  visit() {
    cy.visit("/");
    return this;
  }

  typeUsername(username) {
    this.elements.usernameInput().clear().type(username);
    return this;
  }

  typePassword(password) {
    this.elements.passwordInput().clear().type(password);
    return this;
  }

  clickLogin() {
    this.elements.loginButton().click();
    return this;
  }

  // ---- Kombinə edilmiş hərəkət ----
  login(username, password) {
    this.typeUsername(username);
    this.typePassword(password);
    this.clickLogin();
  }

  // ---- Assertion köməkçiləri ----
  getErrorMessage() {
    return this.elements.errorMessage();
  }
}

export default new LoginPage();
