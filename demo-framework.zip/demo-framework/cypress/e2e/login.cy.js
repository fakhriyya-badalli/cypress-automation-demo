import LoginPage from "../pages/LoginPage";

describe("Login funksionallığı", () => {
  let users;

  before(() => {
    cy.fixture("users").then((data) => {
      users = data;
    });
  });

  beforeEach(() => {
    LoginPage.visit();
  });

  it("Doğru istifadəçi adı və şifrə ilə uğurla login olmalıdır", () => {
    LoginPage.login(users.validUser.username, users.validUser.password);
    cy.url().should("include", "/inventory.html");
  });

  it("Bloklanmış istifadəçi login ola bilməməlidir", () => {
    LoginPage.login(users.lockedUser.username, users.lockedUser.password);
    LoginPage.getErrorMessage()
      .should("be.visible")
      .and("contain.text", "locked out");
  });

  it("Yanlış məlumatlarla xəta mesajı göstərilməlidir", () => {
    LoginPage.login(users.invalidUser.username, users.invalidUser.password);
    LoginPage.getErrorMessage()
      .should("be.visible")
      .and("contain.text", "Username and password do not match");
  });

  it("Boş sahələrlə login düyməsi xəta verməlidir", () => {
    LoginPage.clickLogin();
    LoginPage.getErrorMessage().should("be.visible");
  });
});
