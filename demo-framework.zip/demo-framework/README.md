# Demo Cypress Framework

Saucedemo.com üzərində Page Object Model (POM) pattern-i ilə qurulmuş nümunə E2E automation framework.

## Struktur

- `cypress/e2e/` — test faylları
- `cypress/pages/` — page object class-ları (lokatorlar + hərəkətlər)
- `cypress/fixtures/` — test data (JSON)
- `cypress/support/` — custom command-lar və qlobal config
- `.github/workflows/` — CI/CD (hər push-da testlər avtomatik işə düşür)

## İşə salmaq

```bash
npm install
npm run cy:open   # interaktiv rejim
npm run cy:run    # headless rejim
```

## Prinsiplər

1. **Page Object Model** — hər səhifə üçün ayrıca class, lokatorlar test məntiqindən ayrılır.
2. **Fixture-based data** — istifadəçi adı/şifrə kimi test data hardcode edilmir, JSON-dan oxunur.
3. **Custom commands** — tez-tez təkrarlanan hərəkətlər (login kimi) `commands.js`-də mərkəzləşdirilir.
4. **CI/CD** — hər push/PR zamanı GitHub Actions testləri avtomatik işə salır.
